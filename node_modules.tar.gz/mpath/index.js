'use strict';

module.exports = exports = require('./lib');
